import Cleave from './src/Cleave.react';

export default Cleave;
