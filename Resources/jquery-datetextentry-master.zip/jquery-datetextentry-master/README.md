jquery.datetextentry.js
=======================

This plugin provides a widget for date entry and validation.

See the [documentation page](http://grantm.github.com/jquery-datetextentry/)
for examples and reference documentation.

